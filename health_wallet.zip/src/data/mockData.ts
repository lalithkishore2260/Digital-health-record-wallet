import { Doctor, Patient, MedicalReport } from '@/types';

// Default doctor accounts
export const defaultDoctors: Doctor[] = [
  {
    id: 'DOC001',
    password: 'password123',
    name: 'Dr. Sarah Johnson',
    age: 42,
    dob: '1982-03-15',
    gender: 'Female',
    license: 'DOC001',
    specialization: 'General Medicine',
    phone: '+1-555-0101',
    type: 'doctor'
  },
  {
    id: 'DOC002',
    password: 'password123',
    name: 'Dr. Michael Chen',
    age: 38,
    dob: '1985-07-22',
    gender: 'Male',
    license: 'DOC002',
    specialization: 'Cardiology',
    phone: '+1-555-0102',
    type: 'doctor'
  }
];

// Default patient accounts  
export const defaultPatients: Patient[] = [
  {
    id: 'PAT001',
    password: 'patient123',
    name: 'John Smith',
    age: 39,
    dob: '1985-01-15',
    gender: 'Male',
    phone: '+1234567890',
    status: 'approved',
    medicalConditions: 'Hypertension, managed with medication',
    type: 'patient'
  },
  {
    id: 'PAT002',
    password: 'patient123',
    name: 'Emily Davis',
    age: 28,
    dob: '1996-05-10',
    gender: 'Female',
    phone: '+1987654321',
    status: 'approved',
    medicalConditions: 'No known medical conditions',
    type: 'patient'
  }
];

// Pending patient applications
export const pendingPatients: Patient[] = [
  {
    id: 'PAT003',
    password: 'patient123',
    name: 'Robert Wilson',
    age: 45,
    dob: '1979-08-20',
    gender: 'Male',
    phone: '+1555123456',
    medicalConditions: 'Diabetes Type 2, taking metformin',
    status: 'pending',
    submissionDate: '2024-09-14',
    type: 'patient'
  },
  {
    id: 'PAT004',
    password: 'patient123',
    name: 'Lisa Anderson',
    age: 33,
    dob: '1991-12-03',
    gender: 'Female',
    phone: '+1555987654',
    medicalConditions: 'Asthma, uses inhaler as needed',
    status: 'pending',
    submissionDate: '2024-09-15',
    type: 'patient'
  }
];

// Medical reports
export const defaultReports: MedicalReport[] = [
  {
    id: 'REP001',
    patientId: 'PAT001',
    patientName: 'John Smith',
    doctorId: 'DOC001',
    doctorName: 'Dr. Sarah Johnson',
    date: '2024-09-16',
    symptoms: [
      'Mild headache and fatigue',
      'Occasional dizziness',
      'Sleep disturbances'
    ],
    diagnosis: [
      'Stress-related fatigue syndrome',
      'Mild dehydration',
      'Recommended lifestyle changes'
    ],
    testsconducted: [
      'Complete Blood Count (CBC) - Normal',
      'Blood Pressure Monitoring - 120/80 mmHg',
      'Heart Rate Variability - Within normal range'
    ],
    treatmentPlan: [
      'Increase daily water intake to 8-10 glasses',
      'Regular exercise - 30 minutes daily',
      'Stress management techniques',
      'Follow-up appointment in 2 weeks'
    ],
    additionalNotes: 'Patient is advised to maintain a balanced diet and ensure adequate sleep. Continue monitoring symptoms and report any worsening conditions immediately.',
    status: 'submitted',
    isEditable: true
  },
  {
    id: 'REP002',
    patientId: 'PAT002',
    patientName: 'Emily Davis',
    doctorId: 'DOC002',
    doctorName: 'Dr. Michael Chen',
    date: '2024-09-10',
    symptoms: [
      'Chest tightness during exercise',
      'Shortness of breath',
      'Rapid heartbeat'
    ],
    diagnosis: [
      'Exercise-induced bronchospasm',
      'Mild cardiovascular deconditioning',
      'Recommendation for pulmonary function tests'
    ],
    testsconducted: [
      'Electrocardiogram (ECG) - Normal sinus rhythm',
      'Chest X-ray - Clear lung fields',
      'Spirometry - Mild obstruction pattern'
    ],
    treatmentPlan: [
      'Inhaled bronchodilator before exercise',
      'Gradual increase in exercise intensity',
      'Cardiopulmonary rehabilitation program',
      'Follow-up in 4 weeks'
    ],
    additionalNotes: 'Patient shows good response to bronchodilator therapy. Advised to carry rescue inhaler during physical activities.',
    status: 'confirmed',
    isEditable: false
  }
];