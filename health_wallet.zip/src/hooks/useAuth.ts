import { create } from 'zustand';
import { Doctor, Patient } from '@/types';
import { defaultDoctors, defaultPatients, pendingPatients } from '@/data/mockData';
import { toast } from 'sonner';

interface AuthStore {
  currentUser: Doctor | Patient | null;
  isAuthenticated: boolean;
  doctors: Doctor[];
  patients: Patient[];
  pending: Patient[];
  login: (userType: 'doctor' | 'patient', credentials: { id: string; password: string }) => boolean;
  logout: () => void;
  registerDoctor: (doctorData: Omit<Doctor, 'id' | 'type'>) => boolean;
  registerPatient: (patientData: Omit<Patient, 'id' | 'type' | 'status' | 'submissionDate'>) => boolean;
  approvePatient: (patientId: string) => boolean;
  rejectPatient: (patientId: string) => boolean;
}

export const useAuth = create<AuthStore>((set, get) => ({
  currentUser: null,
  isAuthenticated: false,
  doctors: [...defaultDoctors],
  patients: [...defaultPatients],
  pending: [...pendingPatients],

  login: (userType, credentials) => {
    const { doctors, patients } = get();
    
    if (userType === 'doctor') {
      const doctor = doctors.find(d => d.id === credentials.id && d.password === credentials.password);
      if (doctor) {
        set({ currentUser: doctor, isAuthenticated: true });
        toast.success(`Welcome back, ${doctor.name}!`);
        return true;
      }
    } else {
      const patient = patients.find(p => p.id === credentials.id && p.password === credentials.password);
      if (patient) {
        set({ currentUser: patient, isAuthenticated: true });
        toast.success(`Welcome back, ${patient.name}!`);
        return true;
      }
    }
    
    toast.error('Invalid credentials. Please check your ID and password.');
    return false;
  },

  logout: () => {
    set({ currentUser: null, isAuthenticated: false });
    toast.success('Logged out successfully');
  },

  registerDoctor: (doctorData) => {
    const { doctors } = get();
    const newId = `DOC${String(doctors.length + 1).padStart(3, '0')}`;
    
    const newDoctor: Doctor = {
      ...doctorData,
      id: newId,
      type: 'doctor',
      password: 'password123' // Default password
    };

    const updatedDoctors = [...doctors, newDoctor];
    set({ 
      doctors: updatedDoctors,
      currentUser: newDoctor, 
      isAuthenticated: true 
    });
    
    toast.success(`Doctor account created! Your ID is ${newId}`);
    return true;
  },

  registerPatient: (patientData) => {
    const { pending, patients } = get();
    const totalPatients = pending.length + patients.length;
    const newId = `PAT${String(totalPatients + 1).padStart(3, '0')}`;
    
    const newPatient: Patient = {
      ...patientData,
      id: newId,
      type: 'patient',
      password: 'patient123', // Default password
      status: 'pending',
      submissionDate: new Date().toISOString().split('T')[0]
    };

    const updatedPending = [...pending, newPatient];
    set({ pending: updatedPending });
    
    toast.success('Application submitted successfully! You will be notified once approved.');
    return true;
  },

  approvePatient: (patientId) => {
    const { pending, patients } = get();
    const patientIndex = pending.findIndex(p => p.id === patientId);
    
    if (patientIndex !== -1) {
      const approvedPatient = { ...pending[patientIndex], status: 'approved' as const };
      const updatedPending = pending.filter((_, index) => index !== patientIndex);
      const updatedPatients = [...patients, approvedPatient];
      
      set({ 
        pending: updatedPending, 
        patients: updatedPatients 
      });
      
      toast.success(`Patient ${approvedPatient.name} has been approved!`);
      return true;
    }
    return false;
  },

  rejectPatient: (patientId) => {
    const { pending } = get();
    const patientIndex = pending.findIndex(p => p.id === patientId);
    
    if (patientIndex !== -1) {
      const rejectedPatient = { ...pending[patientIndex], status: 'rejected' as const };
      const updatedPending = [...pending];
      updatedPending[patientIndex] = rejectedPatient;
      
      set({ pending: updatedPending });
      
      toast.success(`Patient ${rejectedPatient.name} application has been rejected.`);
      return true;
    }
    return false;
  }
}));