import { create } from 'zustand';
import { MedicalReport } from '@/types';
import { defaultReports } from '@/data/mockData';
import { toast } from 'sonner';

interface ReportsStore {
  reports: MedicalReport[];
  getPatientReports: (patientId: string) => MedicalReport[];
  getDoctorReports: (doctorId: string) => MedicalReport[];
  getPendingReports: () => MedicalReport[];
  updateReport: (reportId: string, updates: Partial<MedicalReport>) => boolean;
  createReport: (reportData: Omit<MedicalReport, 'id'>) => boolean;
  confirmReport: (reportId: string, doctorId: string) => boolean;
  rejectReport: (reportId: string, doctorId: string, reason?: string) => boolean;
}

export const useReports = create<ReportsStore>((set, get) => ({
  reports: [...defaultReports],

  getPatientReports: (patientId) => {
    const { reports } = get();
    return reports.filter(report => report.patientId === patientId);
  },

  getDoctorReports: (doctorId) => {
    const { reports } = get();
    return reports.filter(report => report.doctorId === doctorId);
  },

  getPendingReports: () => {
    const { reports } = get();
    return reports.filter(report => report.status === 'submitted');
  },

  updateReport: (reportId, updates) => {
    const { reports } = get();
    const reportIndex = reports.findIndex(r => r.id === reportId);
    
    if (reportIndex !== -1) {
      const updatedReports = [...reports];
      updatedReports[reportIndex] = { 
        ...updatedReports[reportIndex], 
        ...updates 
      };
      
      set({ reports: updatedReports });
      toast.success('Report updated successfully!');
      return true;
    }
    return false;
  },

  createReport: (reportData) => {
    const { reports } = get();
    const newId = `REP${String(reports.length + 1).padStart(3, '0')}`;
    
    const newReport: MedicalReport = {
      ...reportData,
      id: newId,
      status: 'draft',
      isEditable: true
    };

    const updatedReports = [...reports, newReport];
    set({ reports: updatedReports });
    
    toast.success('New report created successfully!');
    return true;
  },

  confirmReport: (reportId, doctorId) => {
    const { reports } = get();
    const reportIndex = reports.findIndex(r => r.id === reportId);
    
    if (reportIndex !== -1) {
      const updatedReports = [...reports];
      updatedReports[reportIndex] = {
        ...updatedReports[reportIndex],
        status: 'confirmed',
        isEditable: false,
        doctorId,
        additionalNotes: updatedReports[reportIndex].additionalNotes + 
          `\n\nConfirmed by ${doctorId} on ${new Date().toLocaleDateString()}`
      };
      
      set({ reports: updatedReports });
      toast.success('Report confirmed successfully!');
      return true;
    }
    return false;
  },

  rejectReport: (reportId, doctorId, reason) => {
    const { reports } = get();
    const reportIndex = reports.findIndex(r => r.id === reportId);
    
    if (reportIndex !== -1) {
      const updatedReports = [...reports];
      updatedReports[reportIndex] = {
        ...updatedReports[reportIndex],
        status: 'rejected',
        isEditable: true,
        additionalNotes: updatedReports[reportIndex].additionalNotes + 
          `\n\nRejected by ${doctorId} on ${new Date().toLocaleDateString()}` +
          (reason ? `\nReason: ${reason}` : '')
      };
      
      set({ reports: updatedReports });
      toast.success('Report has been rejected and sent back for revision.');
      return true;
    }
    return false;
  }
}));