export interface User {
  id: string;
  name: string;
  age: number;
  dob: string;
  gender: 'Male' | 'Female' | 'Other';
  phone: string;
  password: string;
}

export interface Doctor extends User {
  license: string;
  specialization: string;
  type: 'doctor';
}

export interface Patient extends User {
  medicalConditions: string;
  status: 'pending' | 'approved' | 'rejected';
  submissionDate?: string;
  type: 'patient';
}

export interface HealthMetrics {
  heartRate: number;
  temperature: number;
  bloodPressure: string;
  oxygenLevel: number;
}

export interface MedicalReport {
  id: string;
  patientId: string;
  patientName: string;
  doctorId?: string;
  doctorName?: string;
  date: string;
  symptoms: string[];
  diagnosis: string[];
  testsconducted: string[];
  treatmentPlan: string[];
  additionalNotes: string;
  status: 'draft' | 'submitted' | 'confirmed' | 'rejected';
  isEditable: boolean;
}

export interface AuthState {
  currentUser: Doctor | Patient | null;
  isAuthenticated: boolean;
}

export interface ChatMessage {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
}