import jsPDF from 'jspdf';
import type { MedicalReport } from '@/types';

export const generateReportPDF = (report: MedicalReport) => {
  const doc = new jsPDF();
  
  // Header
  doc.setFontSize(18);
  doc.setTextColor(0, 102, 204); // Medical blue
  doc.text('Medical Report', 20, 25);
  
  // Report ID and Date
  doc.setFontSize(10);
  doc.setTextColor(100, 100, 100);
  doc.text(`Report ID: ${report.id}`, 20, 35);
  doc.text(`Date: ${new Date(report.date).toLocaleDateString()}`, 20, 42);
  
  // Patient Information
  doc.setFontSize(14);
  doc.setTextColor(0, 0, 0);
  doc.text('Patient Information', 20, 55);
  
  doc.setFontSize(10);
  doc.text(`Name: ${report.patientName}`, 25, 65);
  doc.text(`Patient ID: ${report.patientId}`, 25, 72);
  
  // Doctor Information
  doc.setFontSize(14);
  doc.text('Doctor Information', 20, 100);
  
  doc.setFontSize(10);
  doc.text(`Doctor: ${report.doctorName || 'Not assigned'}`, 25, 110);
  doc.text(`Doctor ID: ${report.doctorId || 'N/A'}`, 25, 117);
  
  // Status
  doc.setFontSize(14);
  doc.text('Report Status', 20, 130);
  
  doc.setFontSize(10);
  const statusColor = report.status === 'confirmed' ? [0, 128, 0] : 
                     report.status === 'rejected' ? [255, 0, 0] : [255, 140, 0];
  doc.setTextColor(statusColor[0], statusColor[1], statusColor[2]);
  doc.text(`Status: ${report.status.toUpperCase()}`, 25, 140);
  
  // Symptoms
  doc.setTextColor(0, 0, 0);
  doc.setFontSize(14);
  doc.text('Symptoms', 20, 155);
  
  doc.setFontSize(10);
  let yPos = 165;
  report.symptoms.forEach((symptom, index) => {
    if (yPos > 280) {
      doc.addPage();
      yPos = 20;
    }
    doc.text(`${index + 1}. ${symptom}`, 25, yPos);
    yPos += 7;
  });
  
  // Diagnosis
  if (report.diagnosis.length > 0) {
    if (yPos > 250) {
      doc.addPage();
      yPos = 20;
    }
    
    doc.setFontSize(14);
    doc.text('Diagnosis', 20, yPos + 10);
    yPos += 20;
    
    doc.setFontSize(10);
    report.diagnosis.forEach((diagnosis, index) => {
      if (yPos > 280) {
        doc.addPage();
        yPos = 20;
      }
      doc.text(`${index + 1}. ${diagnosis}`, 25, yPos);
      yPos += 7;
    });
  }
  
  // Tests Conducted
  if (report.testsconducted.length > 0) {
    if (yPos > 250) {
      doc.addPage();
      yPos = 20;
    }
    
    doc.setFontSize(14);
    doc.text('Tests Conducted', 20, yPos + 10);
    yPos += 20;
    
    doc.setFontSize(10);
    report.testsconducted.forEach((test, index) => {
      if (yPos > 280) {
        doc.addPage();
        yPos = 20;
      }
      doc.text(`${index + 1}. ${test}`, 25, yPos);
      yPos += 7;
    });
  }
  
  // Additional Notes
  if (report.additionalNotes) {
    if (yPos > 250) {
      doc.addPage();
      yPos = 20;
    }
    
    doc.setFontSize(14);
    doc.text('Additional Notes', 20, yPos + 10);
    yPos += 20;
    
    doc.setFontSize(10);
    const lines = doc.splitTextToSize(report.additionalNotes, 170);
    lines.forEach((line: string) => {
      if (yPos > 280) {
        doc.addPage();
        yPos = 20;
      }
      doc.text(line, 25, yPos);
      yPos += 7;
    });
  }
  
  // Footer
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(150, 150, 150);
    doc.text(`Generated on ${new Date().toLocaleDateString()} | Page ${i} of ${pageCount}`, 20, 290);
    doc.text('Smart Health Monitoring System', 20, 297);
  }
  
  // Save the PDF
  doc.save(`medical-report-${report.id}.pdf`);
};

export const downloadReport = (report: MedicalReport) => {
  generateReportPDF(report);
};